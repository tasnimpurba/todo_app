package com.demo.iub.todo_app_iub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
